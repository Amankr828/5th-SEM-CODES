/*
Problem Statement:

Write a java program for adding a new class to an existing package.
Also, implement two public classes in the Java program using packages.

 */

/*
package pack;
public class A {
    public void method(){
    System.out.println("This is from previous class A.");
}
}
 */
/*
package pack;
public class B{
    public void method(){
    System.out.println("This is from previous class B.");
}
}

 */

/*
package pack;
public class C {
    public void method(){
    System.out.println("I am from newly added class C.");
}
}

 */

import pack.A;
import pack.B;
import pack.C;
public class Assignment_15 {
    public static void main(String[] args) {
        A o1=new A();
        o1.method();
        B o2=new B();
        o2.method();
        C o3=new C();
        o3.method();
    }
}

/*
output:
This is from previous class A.
This is from previous class B.
I am from newly added class C.
 */

/*
Discussion:
If we don’t use public class then we can not implement class’s object in the main where package imported.
 */


