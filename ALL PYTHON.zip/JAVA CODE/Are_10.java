interface Area {
    public float Pi = 3.14f;

    public void cal_area(float dim1, float dim2);
}

class Circle implements Area {
    float area;

    public void cal_area(float dim1, float dim2) {
        area = Pi * dim1 * dim1;
        System.out.println("Area of Circle : " + area);
    }
}

class Rectangle implements Area {
    float area;

    public void cal_area(float dim1, float dim2) {
        area = dim1 * dim2;
        System.out.println("Area of Rectangle : " + area);
    }
}

public class Are_10 {
    public static void main(String args[]) {
        Circle C1 = new Circle();
        C1.cal_area(5, 0);
        Rectangle R = new Rectangle();
        R.cal_area(10f, 8f);
    }
}