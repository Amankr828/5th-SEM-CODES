class Arithmetic {
    private int a;
    private float b;
    private char c;
    private double d;

    Arithmetic() {

    }

    Arithmetic(int a, float b, char c, double d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    void add(int x, double y) {
        this.a = this.a + x;
        this.d = this.d + y;
    }

    void add(int x, float y, double z) {
        this.a = this.a + x;
        this.b = this.b + y;
        this.d = this.d + z;
    }

    void add(float x, int y, double z) {
        this.a = this.a + y;
        this.b = this.b + x;
        this.d = this.d + z;
    }

    Arithmetic add(Arithmetic x) {
        Arithmetic A1 = new Arithmetic();
        A1.a = this.a + x.a;
        A1.b = this.b + x.b;
        A1.c = (char) (this.c + x.c);
        A1.d = this.d + x.d;
        return A1;
    }

    public void display() {
        System.out.println("a: " + a + " b: " + b + " c: " + c + " d: " + d);
    }
}

public class Arithmetic_Inheritance {
    public static void main(String args[]) {
        Arithmetic Ar = new Arithmetic(5, 7f, 'M', 8.0);
        Ar.display();
        Ar.add(3, 2.5);
        Ar.display();
        Ar.add(4, 3.4f, 7.5);
        Ar.display();
        Ar.add(3.8f, 3, 7.5);
        Ar.display();
        Arithmetic Ar1 = new Arithmetic(1, 2.5f, 'I', 10.4);
        Arithmetic Ar2;
        Ar2 = Ar.add(Ar1);
        Ar2.display();
    }
}
