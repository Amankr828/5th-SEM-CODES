'/*
Convert the following primitive data types into corresponding wrapper
objects int, char, float, double.
b) Store null values in the int and float variables.
c) Store the Wrapper Objects into primitive types.
d) Considering an array of characters, check whether individual characters are
of lowercase, uppercase, a
*/

public class wrapper7 {
    public static void main(String[] args) {
        char a = 's';
        double b = 2.33;
        Integer i = null;
        Character c = a;
        Float f = null;
        Double d = b;
        System.out.println("Primitive to wrapper class conversion:");
        System.out.println(i + " " + c + " " + f + " " + d);
        Integer a1 = new Integer(5);
        Character a2 = new Character('c');
        Float a3 = new Float(2.33f);
        Double a4 = new Double(2.3);
        int k = a1;
        char l = a2;
        float m = a3;
        double n = a4;
        System.out.println("wrapper class to Primitive conversion:");
        System.out.println(k + " " + l + " " + m + " " + n);
        char[] arr = { 'A', 'a', ' ', 7 };
        System.out.println("Individual characters are:");
        for (int p = 0; p < arr.length; p++) {
            if (arr[p] >= 'A' && arr[p] <= 'Z') {
                System.out.println("Uppercase");
            } else if (arr[p] >= 'a' && arr[p] <= 'z') {
                System.out.println("Lowercase");
            } else if (arr[p] >= 0 && arr[p] <= 9) {
                System.out.println("Digit");
            } else if (arr[p] == ' ') {
                System.out.println("Whitespace");
            } else {
                System.out.println("Special character");
            }
        }
    }
}

/*
 * OUTPUT-
 * ming\Code\User\workspaceStorage\30c3a8f6a1a2489ba0bcaaacd7a67506\redhat.java\
 * jdt_ws\Amanjava_2d6e21d\bin Assignment7 "
 * Primitive to wrapper class conversion:
 * null s null 2.33
 * wrapper class to Primitive conversion:
 * 5 c 2.33 2.3
 * Individual characters are:
 * Uppercase
 * Lowercase
 * Whitespace
 * Digit
 *
 * DISCUSSION-
 * This program showcases the concept of inheritence where specific type of
 * Birds inherit
 * common attributes from Bird base class. It also demonstrates abstraction
 * through abstract
 * 'Fly() method, which is implemented differently in each stor subclass to
 * represent flying
 * and noy nori flying charecteristics of birds.
 */
