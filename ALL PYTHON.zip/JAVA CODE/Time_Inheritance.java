class Time {
    private int hr, min;
    private double sec;

    Time(int hr, int min, double sec) {
        this.hr = hr;
        this.min = min;
        this.sec = sec;
    }

    public void showtime() {
        System.out.println(hr + " Hour, " + min + " Minutes, " + sec + " Seconds");
    }

    public void add_time(int m) {
        this.min = this.min + m;
        if (this.min >= 60) {
            this.hr++;
            this.min %= 60;
        }
    }

    public void add_time(int hr, int min) {
        this.hr = this.hr + hr;
        this.min = this.min + min;
        if (this.min >= 60) {
            this.hr++;
            this.min %= 60;
        }
    }

    public void add_time(double sec) {
        this.hr = this.hr + hr;
        this.min = this.min + min;
        this.sec = this.sec + sec;
        if (this.sec >= 60) {
            this.min += 1;
            this.sec = this.sec - 60;
            if (this.min >= 60) {
                this.hr++;
                this.min %= 60;
            }
        }
    }

    Time add_time(Time T2) {
        Time T3 = new Time(0, 0, 0.0);
        T3.sec = T2.sec + sec;
        T3.min = T2.min + min;
        T3.hr = T2.hr + hr;
        if (T3.sec >= 60) {
            T3.min += 1;
            T3.sec = T3.sec - 60;
        }
        if (T3.min >= 60) {
            T3.hr++;
            T3.min %= 60;
        }
        return T3;
    }
}

public class Time_Inheritance {
    public static void main(String args[]) {
        Time T1 = new Time(5, 60, 0.0);
        System.out.println("Initial Time Object");
        T1.showtime();
        Time T2 = new Time(3, 20, 45.5);
        System.out.println("\nAnother Time Object");
        T2.showtime();
        System.out.println("\nAdding two Time Object");
        Time T3;
        T3 = T1.add_time(T2);
        T3.showtime();
        System.out.println("\nAdding 4 minutes to initial time object T1");
        T1.add_time(4);
        ;
        T1.showtime();
        System.out.println("\nAdding 3hours and 10 minutes to initial time object T1");
        T1.add_time(3, 70);
        T1.showtime();
        System.out.println("\nAdding 50.5 seconds to initial time object T1");
        T1.add_time(50.5);
        T1.showtime();
        System.out.println("\nAdding 40 seconds to 3 hour, 59 minutes and 30 seconds: ");
        Time T4 = new Time(3, 59, 30);
        Time T5 = new Time(0, 0, 40.0);
        Time T6;
        T6 = T4.add_time(T5);
        T6.showtime();
    }
}
