/*
Problem statement :
Write a lava program to create 20 threads and print their Ids.   [Hint: Inherit Thread Class]

 */

class Multithread extends Thread {
    public void run() {
        try {
            System.out.println("New Thread " + Thread.currentThread().getId() + " is running");
        } catch (Exception e) {
            System.out.println("Exception is caught......");
        }
    }
}

public class threads_20 {
    public static void main(String[] args) {
        int n = 20;
        for (int i = 0; i <= n; i++) {
            Multithread object = new Multithread();
            object.start();
        }
    }
}

/*
 * output:
 * 
 * New Thread 20 is running
 * New Thread 24 is running
 * New Thread 21 is running
 * New Thread 26 is running
 * New Thread 23 is running
 * New Thread 29 is running
 * New Thread 30 is running
 * New Thread 22 is running
 * New Thread 32 is running
 * New Thread 31 is running
 * New Thread 28 is running
 * New Thread 27 is running
 * New Thread 25 is running
 * New Thread 34 is running
 * New Thread 33 is running
 * New Thread 36 is running
 * New Thread 38 is running
 * New Thread 37 is running
 * New Thread 39 is running
 * New Thread 35 is running
 * New Thread 40 is running
 * 
 */

/*
 * Discussion:
 * The paint method is a built-in method in the Applet class, overridden here.
 * This method is automatically called whenever the applet needs to be redrawn
 * or updated.
 * 
 */