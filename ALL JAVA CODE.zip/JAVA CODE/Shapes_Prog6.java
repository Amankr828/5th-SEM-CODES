
/*
Write a Java program to create a class "Shape" and 3 other classes named Square,
Rectangle and Triangle derived from it, all containing a overridden
method cal area() to calculate area of a Square or a Rectangle or a Triangle.
ssume suitable data members( 2 int type data members only) and member methods(get()
and put()) in all classes. Also validate the inputs.
*/

import java.util.Scanner;

abstract class Shape {
    public int l, b;

    public abstract void get();

    public abstract void cal_area();
}

class Square extends Shape {
    public void get() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Side Square: ");
        l = sc.nextInt();
    }

    public void cal_area() {
        int area = l * l;
        System.out.println("Area of Square is: " + area);
    }

    public void put() {
        System.out.println("Length of each side: " + l);
    }
}

class Rectangle extends Shape {
    public void get() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length : ");
        l = sc.nextInt();
        System.out.print("Enter breadth: ");
        b = sc.nextInt();
    }

    public void cal_area() {
        int area = l * b;
        System.out.println("Area of Rectangle is: " + area);
    }

    public void put() {
        System.out.println("Length is: " + l);
        System.out.println("Breadth is: " + b);
    }
}

class Triangle extends Shape {
    public void get() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter height: ");
        l = sc.nextInt();
        System.out.print("Enter width: ");
        b = sc.nextInt();
    }

    public void cal_area() {
        double area = 0.5 * l * b;
        System.out.println("Area of Triangle is: " + area);
    }

    public void put() {
        System.out.println("Height is: " + l);
        System.out.println("Width is: " + b);
    }
}

public class Shapes_Prog6 {
    public static void main(String args[]) {
        Square O1 = new Square();
        O1.get();
        O1.put();
        O1.cal_area();

        System.out.println();

        Rectangle o2 = new Rectangle();
        o2.get();
        o2.put();
        o2.cal_area();

        System.out.println();

        Triangle o3 = new Triangle();
        o3.get();
        o3.put();
        o3.cal_area();
    }
}

/*
 * out put-
 * :\Users\AMAN\Desktop\Amanjavapdf>cd "c:\Users\AMAN\Desktop\Amanjavapdf\" &&
 * javac Shapes_Prog6.java && java Shapes_Prog6
 * Enter Side Square:
 * 443
 * Length of each side: 443
 * Area of Square is: 196249
 * 
 * Enter length : 55
 * Enter breadth: 78
 * Length is: 55
 * Breadth is: 78
 * Area of Rectangle is: 4290
 * 
 * Enter height: 45
 * Enter width: 65
 * Height is: 45
 * Width is: 65
 * Area of Triangle is: 1462.5
 * 
 * c:\Users\AMAN\Desktop\Amanjavapdf>
 */
