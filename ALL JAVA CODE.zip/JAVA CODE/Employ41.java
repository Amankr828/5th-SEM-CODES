class Employee {
    String ECode, Ename, ContactNo, Dept;
    double BasicSal, GrossSal;

    Employee(String ec, String en, String con, String d, double bs) {
        ECode = ec;
        Ename = en;
        ContactNo = con;
        Dept = d;
        BasicSal = bs;
        GrossSal = 0;
    }

    void computeTotSalary() {
        double DA, HRA, MA;
        DA = 0.75 * BasicSal;
        HRA = 0.15 * BasicSal;
        MA = 0.10 * BasicSal;
        GrossSal = BasicSal + DA + HRA + MA;
    }

    double calcBonus(double bonus) {
        return (bonus / 100) * BasicSal;
    }

    void showdata(double bonus) {
        System.out.println("Code :" + ECode);
        System.out.println("Name :" + Ename);
        System.out.println("Contact Number :" + ContactNo);
        System.out.println("Department :" + Dept);
        System.out.println("Basic Salary :" + BasicSal);
        System.out.println("Bonus :" + bonus);
        System.out.println("Gross Salary :" + GrossSal + bonus);
    }
}

class Manager extends Employee {
    String MgrID, Dept_Managed;

    Manager(String ec, String en, String con, String d, float bs, String id, String dep) {
        super(ec, en, con, d, bs);
        MgrID = id;
        Dept_Managed = dep;
    }

    void show() {
        double b = calcBonus(30);
        System.out.println("\nPost: Manager");
        System.out.println("ID: " + MgrID);
        showdata(b);
    }
}

class Engineer extends Employee {
    String Project_Assg;

    Engineer(String ec, String en, String con, String d, float bs, String pro) {
        super(ec, en, con, d, bs);
        Project_Assg = pro;
    }

    void show() {
        double bonus = calcBonus(20);
        System.out.println("\nPost: Engineer");
        showdata(bonus);
    }
}

class Clerk extends Employee {
    String Clerk_Type;

    Clerk(String ec, String en, String con, String d, float bs, String CT) {
        super(ec, en, con, d, bs);
        Clerk_Type = CT;
    }

    void show() {
        double bonus = calcBonus(10);
        System.out.println("\nPost: Clerk");
        showdata(bonus);
    }
}

public class Employ41 {
    public static void main(String[] args) {
        Manager ob1 = new Manager("1001", "Anisha", "9876543211", "CSE", 10000, "878", "Computer");
        ob1.computeTotSalary();
        ob1.show();
        Engineer ob2 = new Engineer("1002", "Alisha", "8945626542", "CSE", 5000, "Software Design");
        ob2.computeTotSalary();
        ob2.show();
        Clerk ob3 = new Clerk("1003", "Anshu", "9300213654", "CSE", 2000, "General");
        ob3.computeTotSalary();
        ob3.show();
    }
}
/*
 * OUTPUT
 * Post: Manager
ID: 878
Code :1001
Name :Anisha
Contact Number :9876543211
Department :CSE
Basic Salary :10000.0
Bonus :3000.0
Gross Salary :20000.03000.0

Post: Engineer
Code :1002
Name :Alisha
Contact Number :8945626542
Department :CSE
Basic Salary :5000.0
Bonus :1000.0
Gross Salary :10000.01000.0

Post: Clerk
Code :1003
Name :Anshu
Contact Number :9300213654
Department :CSE
Basic Salary :2000.0
Bonus :200.0
Gross Salary :4000.0200.0

C:\Users\amank\OneDrive\Desktop\Amanjava>
 */