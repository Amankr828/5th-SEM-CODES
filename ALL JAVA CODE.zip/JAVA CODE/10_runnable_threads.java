/*
Problem statement:
Write a Java program to create 10 threads and point their names implementing Runnable interface.
Where sleep mettiod to control working of threads. Use appropriaty exception handling techniques

 */

class thread implements Runnable {
    String name;

    thread(String name) {
        this.name = name;
    }

    public void run() {
        try {
            System.out.println(name + " is running");
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.out.println(name + " is inturrupted...");
        }
    }

}public class 10_ runnable_threads{

    public static void main(String[] args) {
        int n = 10;
        for (int i = 0; i < n; i++) {
            thread new_thread = new thread("Thread-" + i);
            new_thread.run();
        }
    }
}

/*
 * output:-
 * 
 * Thread-0 is running
 * Thread-1 is running
 * Thread-2 is running
 * Thread-3 is running
 * Thread-4 is running
 * Thread-5 is running
 * Thread-6 is running
 * Thread-7 is running
 * Thread-8 is running
 * Thread-9 is running
 */

/*
 * Discussion:
 * This applet retrieves the current system date using java.util.Date, converts
 * it to a string, and then displays it on the applet window using
 * Graphics.drawString().
 * 
 */