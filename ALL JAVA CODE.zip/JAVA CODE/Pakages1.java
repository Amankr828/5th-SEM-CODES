/*
Problem Statement:
Show with a suitable java program that when we import any package ,only the objects of public classes
contained within the imported package can be created and used directly but the non public classes contained
within the package are hidden and can not be used.
 */

/*
package pack;
public class A {
    public void method(){
    System.out.println("This is from previous class A.");
}
}
 */
/*
package pack;
public class B{
    public void method(){
    System.out.println("This is from previous class B.");
}
}

 */

import pack.A;
public class Assignment_14 {
    public static void main(String[] args) {
        A o1=new A();
        o1.method();
        B o2=new B();
        o2.method();
    }
}
/*
OUTPUT:
java: cannot find symbol
 symbol:   class B
 location: class Assignment_14
 */

/*
Discussion:
If we don’t use public class then we can not implement class’s object in the main where package imported.
 */