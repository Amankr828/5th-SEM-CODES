/*2. Create a class Account containing data members constructor for creating Create the following 3 Savings_Ac Account Objects and show()

Acc No, C_Name, Contact_No as data members and a method for displaying the data members. specialized features in all of the above classes for creating objects and showdata() methods for displaying the data members. etc.

Current_Ac

sub-classes, namely, containing specialized features containing specialized features viz. Acc_Balance, Min_Balance

viz. ROI, Acc_Balance viz. Principal, Term, ROI, Maturity_Balance

TD_Ac containing Define suitable constructors Also, define compute() method for different computations in all classes

such as interest calculations */

class Account {
    private int accNo;
    private String cName;
    private String contactNo;

    public Account(int accNo, String cName, String contactNo) {
        this.accNo = accNo;
        this.cName = cName;
        this.contactNo = contactNo;
    }

    public void show() {
        System.out.println("Account Number: " + accNo);
        System.out.println("Customer Name: " + cName);
        System.out.println("Contact Number: " + contactNo);
    }
}

class Savings_Ac extends Account {
    public Savings_Ac(int accNo, String cName, String contactNo) {
        super(accNo, cName, contactNo);
    }

    public void showData() {
        System.out.println("Savings Account Details:");
        show();
    }
}

class Current_Ac extends Account {
    private double accBalance;
    private double minBalance;

    public Current_Ac(int accNo, String cName, String contactNo, double accBalance, double minBalance) {
        super(accNo, cName, contactNo);
        this.accBalance = accBalance;
        this.minBalance = minBalance;
    }

    public void showData() {
        System.out.println("Current Account Details:");
        show();
        System.out.println("Account Balance: " + accBalance);
        System.out.println("Minimum Balance: " + minBalance);
    }
}

class FD_Ac extends Account {
    private double principal;
    private int term;
    private double roi;

    public FD_Ac(int accNo, String cName, String contactNo, double principal, int term, double roi) {
        super(accNo, cName, contactNo);
        this.principal = principal;
        this.term = term;
        this.roi = roi;
    }

    public void compute() {
        double interest = (principal * term * roi) / 100;
        double maturityBalance = principal + interest;
        System.out.println("Interest Earned: " + interest);
        System.out.println("Maturity Balance: " + maturityBalance);
    }

    public void showData() {
        System.out.println("Fixed Deposit Account Details:");
        show();
        System.out.println("Principal Amount: " + principal);
        System.out.println("Term (in years): " + term);
        System.out.println("Rate of Interest: " + roi);
        compute();
    }
}

class TD_Ac extends Account {
    private double accBalance;
    private double minBalance;
    private int term;
    private double roi;

    public TD_Ac(int accNo, String cName, String contactNo, double accBalance, double minBalance, int term,
            double roi) {
        super(accNo, cName, contactNo);
        this.accBalance = accBalance;
        this.minBalance = minBalance;
        this.term = term;
        this.roi = roi;
    }

    public void compute() {
        double interest = (accBalance * term * roi) / 100;
        double maturityBalance = accBalance + interest;
        System.out.println("Interest Earned: " + interest);
        System.out.println("Maturity Balance: " + maturityBalance);
    }

    public void showData() {
        System.out.println("Term Deposit Account Details:");
        show();
        System.out.println("Account Balance: " + accBalance);
        System.out.println("Minimum Balance: " + minBalance);
        System.out.println("Term (in years): " + term);
        System.out.println("Rate of Interest: " + roi);
        compute();
    }
}

public class Account_Inheritance {
    public static void main(String[] args) {
        Savings_Ac savingsAc1 = new Savings_Ac(1001, "John Doe", "123-456-7890");
        savingsAc1.showData();

        System.out.println();

        Current_Ac currentAc1 = new Current_Ac(2001, "Jane Doe", "987-654-3210", 5000, 1000);
        currentAc1.showData();

        System.out.println();

        FD_Ac fdAc1 = new FD_Ac(3001, "Alice Wonderland", "111-222-3333", 10000, 5, 8);
        fdAc1.showData();

        System.out.println();

        TD_Ac tdAc1 = new TD_Ac(4001, "Bob Builder", "444-555-6666", 8000, 2000, 3, 6);
        tdAc1.showData();
    }
}

/*
 * 
 * Savings Accunt Details:
 * Account Number: 1001
 * Customer Name: John Doe
 * Contact Number:123-456-7890
 * 
 * 
 * Current AccountDetails:
 * Account Number: 001
 * Customer Name: Jne Doe
 * Contact Number: 987-654-3210
 * Account Balan
 * e: 5000.0
 * Minimum Balance 1000.0
 * 
 * 
 * Fixed Deposit Acount Details:
 * Account Number: 301
 * 
 * Customer Name: Alice Wonderland
 * Contact Number: 111-222-3333
 * Principal Amount: 10000.0
 * Term (in years): 5
 * Rate of Interest: 8.0
 * Interest Earned: 4000.0
 * Maturity Balance: 14000.0
 * 
 * Term Deposit Account Details:
 * Account Number: 4001
 * Customer Name: Bob Buil
 * 
 * Contact Number: 444-555-6666
 * Account Balance: 8000.0
 * Minimum Balance: 2000.0
 * Term (in years): 3
 * Rate
 * Maturity Balance: 9440.0
 */
/*
 * In the provided Java implementation, we've defined a hierarchy of classes
 * representing
 * different types of bank accounts, such as Savings Account,
 * Current Account, Fixed Deposit Account, and Term Deposit Account.
 * Each class inherits from the base class "Account" and has
 * specialized features like account balance, minimum balance,
 * principal amount, term, and rate of interest. The showData
 * methods display the relevant information, and the compute methods
 * in FD_Ac and TD_Ac calculate and display interest and maturity balance.
 * Finally, in the Main class, we create instances of these accounts and
 * showcase
 * their details, demonstrating the flexibility of object-oriented programming
 * in modeling diverse financial accounts.
 * 
 * 
 * 
 * 
 * 
 */
/*
 * +-----------------------+
 * | Account |
 * +-----------------------+
 * | - accNo: int |
 * | - cName: String |
 * | - contactNo: String |
 * +-----------------------+
 * | + Account(int, String, String) |
 * | + show(): void |
 * +-----------------------+
 * |
 * |
 * V
 * +-------------------+
 * | Savings_Ac |
 * +-------------------+
 * | + showData(): void|
 * +-------------------+
 * |
 * |
 * V
 * +-------------------+
 * | Current_Ac |
 * +-------------------+
 * | - accBalance: double|
 * | - minBalance: double|
 * +-------------------+
 * | + Current_Ac(int, String, String, double, double) |
 * | + showData(): void|
 * +-------------------+
 * |
 * |
 * V
 * +-------------------+
 * | FD_Ac |
 * +-------------------+
 * | - principal: double|
 * | - term: int |
 * | - roi: double |
 * +-------------------+
 * | + FD_Ac(int, String, String, double, int, double) |
 * | + compute(): void |
 * | + showData(): void|
 * +-------------------+
 * |
 * |
 * V
 * +-------------------+
 * | TD_Ac |
 * +-------------------+
 * | - accBalance: double|
 * | - minBalance: double|
 * | - term: int |
 * | - roi: double |
 * +-------------------+
 * | + TD_Ac(int, String, String, double, double, int, double) |
 * | + compute(): void |
 * | + showData(): void|
 * +-------------------+
 * 
 */