class ComputerProfessional {
    protected String EName;
    protected int DutyHour;
    protected String Prospect;

    public ComputerProfessional(String EName, int DutyHour, String Prospect) {
        this.EName = EName;
        this.DutyHour = DutyHour;
        this.Prospect = Prospect;
    }

    public void display() {
        System.out.println("Employee Name: " + EName);
        System.out.println("Duty Hours: " + DutyHour);
        System.out.println("Prospect: " + Prospect);
    }
}

class Developer extends ComputerProfessional {
    protected int StudyHour;

    public Developer(String EName, int DutyHour, String Prospect, int StudyHour) {
        super(EName, DutyHour, Prospect);
        this.StudyHour = StudyHour;
    }

    public void display() {
        super.display();
        System.out.println("Study Hours: " + StudyHour);
    }
}

class NetworkAdmin extends ComputerProfessional {
    protected int PracticeHours;

    public NetworkAdmin(String EName, int DutyHour, String Prospect, int PracticeHours) {
        super(EName, DutyHour, Prospect);
        this.PracticeHours = PracticeHours;
    }

    public void display() {
        super.display();
        System.out.println("Practice Hours: " + PracticeHours);
    }
}

class DataOperator extends ComputerProfessional {
    protected int TypingSpeed;

    public DataOperator(String EName, int DutyHour, String Prospect, int TypingSpeed) {
        super(EName, DutyHour, Prospect);
        this.TypingSpeed = TypingSpeed;
    }

    public void display() {
        super.display();
        System.out.println("Typing Speed: " + TypingSpeed);
    }
}

class JavaProfessional extends Developer {
    protected String ProficiencyLevel;

    public JavaProfessional(String EName, int DutyHour, String Prospect, int StudyHour, String ProficiencyLevel) {
        super(EName, DutyHour, Prospect, StudyHour);
        this.ProficiencyLevel = ProficiencyLevel;
    }

    public void display() {
        super.display();
        System.out.println("Proficiency Level: " + ProficiencyLevel);
    }
}

class PythonProfessional extends Developer {
    protected String ProficiencyLevel;

    public PythonProfessional(String EName, int DutyHour, String Prospect, int StudyHour, String ProficiencyLevel) {
        super(EName, DutyHour, Prospect, StudyHour);
        this.ProficiencyLevel = ProficiencyLevel;
    }

    public void display() {
        super.display();
        System.out.println("Proficiency Level: " + ProficiencyLevel);
    }
}

public class ComputerProfessional_Inheritance {
    public static void main(String[] args) {
        Developer developer = new Developer("John Doe", 40, "Excellent", 10);
        developer.display();

        System.out.println();

        NetworkAdmin networkAdmin = new NetworkAdmin("Jane Doe", 45, "Good", 8);
        networkAdmin.display();

        System.out.println();

        DataOperator dataOperator = new DataOperator("Alice Wonderland", 35, "Fair", 60);
        dataOperator.display();

        System.out.println();

        JavaProfessional javaProfessional = new JavaProfessional("Bob Builder", 50, "Excellent", 12, "Pro");
        javaProfessional.display();

        System.out.println();

        PythonProfessional pythonProfessional = new PythonProfessional("Eve Developer", 48, "Good", 15, "Intermediate");
        pythonProfessional.display();
    }
}
/*
 * +-----------------------+
 * | ComputerProfessional|
 * +-----------------------+
 * | - EName: String |
 * | - DutyHour: int |
 * | - Prospect: String |
 * +-----------------------+
 * | + display(): void |
 * +-----------------------+
 * |
 * |
 * V
 * +-------------------+
 * | Developer |
 * +-------------------+
 * | - StudyHour: int |
 * +-------------------+
 * | + display(): void |
 * +-------------------+
 * |
 * |
 * V
 * +---------------------+
 * | NetworkAdmin |
 * +---------------------+
 * | - PracticeHours: int|
 * +---------------------+
 * | + display(): void |
 * +---------------------+
 * |
 * |
 * V
 * +---------------------+
 * | DataOperator |
 * +---------------------+
 * | - TypingSpeed: int |
 * +---------------------+
 * | + display(): void |
 * +---------------------+
 * |
 * |
 * V
 * +---------------------+
 * | JavaProfessional |
 * +---------------------+
 * | - ProficiencyLevel: |
 * | String |
 * +---------------------+
 * | + display(): void |
 * +---------------------+
 * |
 * |
 * V
 * +----------------------+
 * | PythonProfessional |
 * +----------------------+
 * | - ProficiencyLevel: |
 * | String |
 * +----------------------+
 * | + display(): void |
 * +----------------------+
 * 
 */
/*
 * Employee Name: John Doe
Duty Hours: 40
Prospect: Excellent
Study Hours: 10

Employee Name: Jane Doe
Duty Hours: 45
Prospect: Good
Practice Hours: 8

Employee Name: Alice Wonderland
Duty Hours: 35
Prospect: Fair
Typing Speed: 60

Employee Name: Bob Builder
Duty Hours: 50
Prospect: Excellent
Study Hours: 12
Proficiency Level: Pro

Employee Name: Eve Developer
Duty Hours: 48
Prospect: Good
Study Hours: 15
Proficiency Level: Intermediate
 */