class Complex {
    private int a;
    private int b;

    // Parameterized constructor to initialize the complex numbers
    public Complex(int a, int b) {
        this.a = a;
        this.b = b;
    }

    // Method to perform addition of two complex numbers
    public Complex add(Complex other) {
        int resultA = this.a + other.a;
        int resultB = this.b + other.b;
        return new Complex(resultA, resultB);
    }

    // Method to perform subtraction of two complex numbers
    public Complex sub(Complex other) {
        int resultA = this.a - other.a;
        int resultB = this.b - other.b;
        return new Complex(resultA, resultB);
    }

    // Method to display the complex number
    public void display() {
        System.out.println("(" + a + " + " + b + "i)");
    }
}

public class Complex1 {
    public static void main(String[] args) {
        // Create two Complex objects
        Complex complex1 = new Complex(3, 4);
        Complex complex2 = new Complex(1, 2);

        // Perform addition and display the result
        Complex sum = complex1.add(complex2);
        System.out.print("Sum: ");
        sum.display();

        // Perform subtraction and display the result
        Complex difference = complex1.sub(complex2);
        System.out.print("Difference: ");
        difference.display();
    }
}
