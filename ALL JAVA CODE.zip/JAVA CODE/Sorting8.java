
/*
 * Implement Bubble sort/Insertion sort by taking user input inside an array of
integers. Use object oriented feature only.
 */
import java.util.Scanner;

class Bubblesort {
    int n, a[];

    Bubblesort(int p) {
        n = p;
        a = new int[n];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }
    }

    void sorting() {
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (a[j] > a[j + 1]) {
                    int t = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = t;
                }
            }
        }
    }

    void dispaly() {
        for (int i = 0; i < n; i++) {
            System.out.println(a[i] + " ");
        }
    }
}

class Insertionsort {
    int n, a[];

    Insertionsort(int p) {
        n = p;
        a = new int[n];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter array elements:");
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }
    }

    void sorting() {
        for (int i = 1; i < n; i++) {
            int k = a[i];
            int j = i - 1;
            while (j >= 0 && (a[j] > k)) {
                a[j + 1] = a[j];
                j = j - 1;
            }
            a[j + 1] = k;
        }
    }

    void dispaly() {
        for (int i = 0; i < n; i++) {
            System.out.println(a[i] + " ");
        }
    }
}

public class Sorting8 {
    public static void main(String[] args) {
        Bubblesort o1 = new Bubblesort(5);
        System.out.println("Before bubble sort:");
        o1.dispaly();
        o1.sorting();
        System.out.println("After bubble sort:");
        o1.dispaly();
        Insertionsort o2 = new Insertionsort(5);
        System.out.println("Before insertion sort:");
        o2.dispaly();
        o2.sorting();
        System.out.println("After insertion sort:");
        o2.dispaly();
    }
}

/*
 * OUTPUT
 * Enter array elements:
 * 23 4 1 45 6
 * Before bubble sort:
 * 23
 * 4
 * 1
 * 45
 * 6
 * After bubble sort:
 * 1
 * 4
 * 6
 * 23
 * 45
 * Enter array elements:
 * 34 5 67 8 9
 * Before insertion sort:
 * 34
 * 5
 * 67
 * 8
 * 9
 * After insertion sort:
 * 5
 * 8
 * 9
 * 34
 * 67
 *
 * C:\Users\amank\OneDrive\Desktop\Amanjava>
 *
 * Discussion:
 * Here, we have used object method for array sorting. We have used both
 * bubblesort and insertionsort for array sorting
 *
 */