import java.util.Scanner;

class Discount {
    private double salesAmount;
    private double discount;

    // Constructor to initialize salesAmount
    public Discount(double salesAmount) {
        this.salesAmount = salesAmount;
    }

    // Method to compute discount using if-else construct
    public void compute1() {
        if (salesAmount < 10000) {
            discount = 0;
        } else if (salesAmount < 20000) {
            discount = 0.03 * salesAmount;
        } else if (salesAmount < 40000) {
            discount = 0.05 * salesAmount;
        } else {
            discount = 0.1 * salesAmount;
        }
    }

    // Method to compute discount using ternary operator
    public void compute2() {
        discount = (salesAmount < 10000) ? 0
                : (salesAmount < 20000) ? 0.03 * salesAmount
                        : (salesAmount < 40000) ? 0.05 * salesAmount : 0.1 * salesAmount;
    }

    // Method to display the calculated discount
    public void display() {
        System.out.println("Sales Amount: INR " + salesAmount);
        System.out.println("Discount: INR " + discount);
    }
}

public class Discount2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input sales amount
        System.out.print("Enter the Sales Amount: ");
        double salesAmount = scanner.nextDouble();

        // Create Discount object
        Discount discountObject = new Discount(salesAmount);

        // Compute discount using if-else construct
        // discountObject.compute1();
        // Alternatively, compute discount using ternary operator
        discountObject.compute2();

        // Display the calculated discount
        discountObject.display();

        // Close the scanner
        // scanner.close();
    }
}
/*
 * OUTPUT
 * Enter the Sales Amount: 15000
 * Sales Amount: INR 15000.0
 * Discount: INR 450.0
 * 
 */