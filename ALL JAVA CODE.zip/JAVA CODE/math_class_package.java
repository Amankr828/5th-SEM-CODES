/*
Question:
Write a java program to import Math class defined within java.lang system package and use the value of PI defined there for finding the area and perimeter of a circle by accepting radius as input through suitable methods defined in a user defined class named Math_operations.
Declare object of the class Math_operations and invoke the member functions as per requirement.
Write a java program to import Math class defined within java.lang system package and use the value of PI defined there for finding the area and perimeter of a circle by accepting radius as input through suitable methods defined in a user defined class named Math_operations.
Declare object of the class Math_operations and invoke the member functions as per requirement.
 */

import java.lang.Math;
class Math_Operations {
    public double calculateArea(double radius) {
        return Math.PI * Math.pow(radius, 2);
    }
    public double calculatePerimeter(double radius) {
        return 2 * Math.PI * radius;
    }
}
public class Assignment_12 {
    public static void main(String[] args) {
        Math_Operations o = new Math_Operations();
        double radius = 8.0;
        double area = o.calculateArea(radius);
        double perimeter = o.calculatePerimeter(radius);
        System.out.println("Circle with radius " + radius+" units");
        System.out.println("Area: " + area+" sq.units");
        System.out.println("Perimeter: " + perimeter+" units");
    }
}

/*
OUTPUT:
Circle with radius 8.0 units
Area: 201.06192982974676 sq.units
Perimeter: 50.26548245743669 units
 */

/*
Discussion:
Here we have used package java.lang.Math and used pow and pi from that package.
 */